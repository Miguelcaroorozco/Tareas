/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.sql.*;

public class Clientes {
    private String nombre;
    private String email;
    private String username;
    private String clave;
    private String sexo;
    private int numeroRandom;

    public ResultSet listarClientes() {
        Conector db = new Conector();
        ResultSet rs = null;

        try {
            db.conectar();
            String query = "SELECT Id, Nombre, Email, Username, Clave, Sexo, `Numero random` FROM clientes";
            rs = db.executeSelect(query);
        } catch (SQLException e) {
            System.err.println("Error al listar los clientes: " + e.getMessage());
        }
        return rs;
    }

    public int guardarCliente(String nombre, String email, String username, String clave, String sexo, int numeroRandom) throws SQLException {
        Conector db = new Conector();
        db.conectar();
        String query = "INSERT INTO clientes (Nombre, Email, Username, Clave, Sexo, `Numero random`) VALUES (?, ?, ?, ?, ?, ?)";
        return db.executeUpdate(query, nombre, email, username, clave, sexo, numeroRandom);
    }

    public int actualizarCliente(int id, String nombre, String email, String username, String clave, String sexo, int numeroRandom) throws SQLException {
        Conector db = new Conector();
        db.conectar();
        String query = "UPDATE clientes SET Nombre = ?, Email = ?, Username = ?, Clave = ?, Sexo = ?, `Numero random` = ? WHERE Id = ?";
        return db.executeUpdate(query, nombre, email, username, clave, sexo, numeroRandom, id);
    }

    public int eliminarCliente(int id) throws SQLException {
        Conector db = new Conector();
        db.conectar();
        String query = "DELETE FROM clientes WHERE Id = ?";
        return db.executeUpdate(query, id);
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getNumeroRandom() {
        return numeroRandom;
    }

    public void setNumeroRandom(int numeroRandom) {
        this.numeroRandom = numeroRandom;
    }
}
